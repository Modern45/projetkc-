﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRototypProjektNr1

{

    class Program
    {
        static float MPobliczanieSumy()
        {
            //obliczanie sumy mteodą method call
            //wczytanie 1 liczby sumy
            Console.WriteLine("");
            Console.WriteLine("Podaj pierwsza licze do obliczania sumy: ");
            float MPa;
            //warunek spełnienia liczby a
            while (!float.TryParse(Console.ReadLine(), out MPa))
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            // wczytanie 2 liczby
            Console.WriteLine("Podaj druga licze do obliczenia sumy: ");
            float MPb;
            //warunek spełnienia liczby b
            while (!float.TryParse(Console.ReadLine(), out MPb))
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            //zwrócenie wartości sumy
            return MPa + MPb;
            Console.WriteLine("");
        }

        static float MPobliczanieIloczynu()
        {// obliczanie iloczynu metodą method call
            //wczytanie 1 liczby iloczynu
            Console.WriteLine("");
            Console.WriteLine("Podaj pierwsza licze do obliczania iloczynu: ");
            float MPa;
            //warunek spełniający licze a
            while (!float.TryParse(Console.ReadLine(), out MPa))
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            // wczytanie 2 liczby iloczynu
            Console.WriteLine("Podaj druga licze do obliczania iloczynu: ");
            float MPb;
            //warunek liczby b
            while (!float.TryParse(Console.ReadLine(), out MPb))
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            //zwrócenie wyniku iloczynu
            return MPa * MPb;
            Console.WriteLine("");
        }
        static float MPSredniaArtmetyczna()
        {//obliczenie średniej geometrycznej metodą method call
            int MPn;
            float MPa, MPsuma;
            MPsuma = 0.0f;
            
            Console.WriteLine("\n\n\tŚrednia arytmetyczna method call \n");

            do

            {//wczytanie ilości wyrazów ciągu
                Console.WriteLine("\n\tPodaj liczność ciągu liczbowego n: \n\t");
                while (!int.TryParse(Console.ReadLine(), out MPn))
                {//warunek 
                    Console.WriteLine("\n\t\aERROR: w zapisie liczby n wystąpił" + "niewłaściwy znak");
                    Console.WriteLine("\n\tPodj wartość n jeszcze raz, ale uważaj " + "co piszesz!: \n");
                }
                if (MPn <= 0)
                {
                    Console.WriteLine("n musi być większe od 0");
                    Console.WriteLine("\n\tPodj wartość n jeszcze raz, ale uważaj " + "co piszesz!: \n");
                }
            }

            while (MPn <= 0);

         
            for (int MPi = 1; MPi <= MPn; MPi++) // zmieniam 0 na 1
            {//wprowadzenie wyrazów ciągu liczbowego
                Console.Write("\n\tPodaj {0}-ą wartość wyrazu ciągu liczbowego: ", MPi);
                while (!float.TryParse(Console.ReadLine(), out MPa))
                {//warunek ciągu 
                    Console.WriteLine("\n\tERROR");
                    Console.WriteLine("\n\tPodj wartość n jeszcze raz, ale uważaj " + "co piszesz!: \n");
                }
                //wzór na sumę
                MPsuma = MPsuma + MPa;

            }// wzór na średnią
            float MPsuma1 = MPsuma / MPn;

            Console.WriteLine("\n\tIloczyn {0} wyrazów ciągu libowego jest równa: " + "{1,6:F3}",MPn, MPsuma1);
         

            return MPsuma1;
        }
        static float MPObliczanieJednostkiPaszy()
        {//obliczenie jednostki paszy metodą method call

            Console.WriteLine("");
            // wprowadzenie ilości kilogramów żyta
            Console.WriteLine("Ile kilo żyta: ");
            float MPa, MPb, MPkg, MPkg1;
            //waruenk
            while (!float.TryParse(Console.ReadLine(), out MPa))
            {
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            }
            //wprowadznie ceny kilograma żyta
            Console.WriteLine("Podaj cenę za kilo: ");

            while (!float.TryParse(Console.ReadLine(), out MPkg))
            {//wprowadznie ilości kilogramów pszenicy
                Console.WriteLine("Ile kilo przenicy: ");
            }
            //warunek
            while (!float.TryParse(Console.ReadLine(), out MPb))
            {
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            }
            // wprowadzenie ceny kilograma pszenicy
            Console.WriteLine("Podaj cenę za kilo: ");
            //warunek
            while (!float.TryParse(Console.ReadLine(), out MPkg1))
            {
                Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
            }
            // obliczenie jednostki paszy
            return (MPa * MPkg + MPb * MPkg1) / (MPkg + MPkg1);

        }
        public static double MPSrednia_Geometryczna()
        {// oblicznie sredniej geometrycznej metoda method call
            // wprowadzenie ilosci liczb
            Console.WriteLine("\n\tPodaj ilosc liczb: ");
            int MPilosc = Convert.ToInt32(Console.ReadLine());
            // wprowadzenie liczb uzytkownika
            Console.WriteLine("\n\t podaj swoje liczby:");
            double MPmultiplying = 1;
            for (int MPi = 0; MPi < MPilosc; MPi++)
            {
                MPmultiplying *= Convert.ToDouble(Console.ReadLine());
            }
            // zwrocenie wyniku sredniej geometrycznej
            return Math.Pow(MPmultiplying, 1.0 / MPilosc);
        }
        public static double MPSrednia_Harmoniczna()
        {// obliczenie sredniej harmonicznej metoda method call
            // wprowadzenie ilosci liczb
            Console.WriteLine("\n\t Podaj ilosc liczb: ");
            int MPilosc = Convert.ToInt32(Console.ReadLine());
            // wprowadzenie liczb uzytkownika
            Console.WriteLine("\n\t podaj swoje liczby");
            double MPsum = 0;
            for (int MPi = 0; MPi < MPilosc; MPi++)
               
            {
                MPsum += 1 / Convert.ToDouble(Console.ReadLine());
            }
            //zwrocenie wyniku sredniej harmonicznej
            return MPilosc / MPsum;
        }
        static void Main(string[] args)
        {

            //deklaracja lokalne 
            ConsoleKeyInfo wybranafunkcjonalność;
            // wypisanie metryki programu
            Console.WriteLine("\n\n\tProgram umożliwia wieloktrotne obliczanie: sum, iloczynów i różnych średnich ciągów liczbowych");
            //zapis wielokrtonego powtarzania obliczeń
            do
            {
                //wypisanie funkcjonalnego menu programu
                Console.WriteLine("\n\t funkcjonalne menu programu: ");
                Console.WriteLine("\n\t A. obliczrenie sumy (in-line)");
                Console.WriteLine("\n\t B. obliczrenie sumy (method-call)");
                Console.WriteLine("\n\t C. obliczrenie iloczynu (in-line)");
                Console.WriteLine("\n\t D. obliczrenie iloczynu (method-call)");
                Console.WriteLine("\n\t E. obliczenie średniej arytmetycznej (in-line)");
                Console.WriteLine("\n\t F. obliczenie średniej arytmetycznej (method-call)");
                Console.WriteLine("\n\t G. obliczenie średniej ważonej (in-line) ");
                Console.WriteLine("\n\t H. obliczenie średniej ważonej (method-call) ");
                Console.WriteLine("\n\t I. obliczenie ceny jednostki paszy (in-line) ");
                Console.WriteLine("\n\t J. obliczenie ceny jednostki paszy (method-call) ");
                Console.WriteLine("\n\t K. obliczenie średniej harmonicznej (in-line) ");
                Console.WriteLine("\n\t L. obliczenie średniej harmonicznej (method-call) ");
                Console.WriteLine("\n\t M. obliczenie średniej geometrycznej (in-line) ");
                Console.WriteLine("\n\t N. obliczenie średniej geometrycznej (method-call) ");
                Console.WriteLine("\n\t O. obliczenie średniej kwadratowej (in-line) ");
                Console.WriteLine("\n\t P. obliczenie średniej kwadratowej (method-call) ");
                Console.WriteLine("\n\t Q. obliczenie średniej potęgowej (in-line) ");
                Console.WriteLine("\n\t R. obliczenie średniej potęgowej (method-call) ");
                Console.WriteLine("\n\t X. Zakończenie <wyjście z> programu");
                //wypisanie informacji dla użytkownika co ma teraz zrobić 
                Console.Write("\n\t Naciśnij klawisz odpowiadający wymaganej funkcjonalności: ");
                //wczytanie wybranej funkcjonalności 
                wybranafunkcjonalność = Console.ReadKey();
                // rozpoznac wybraną funkcjonalnośc i ją obsłużyć 
                if (wybranafunkcjonalność.Key == ConsoleKey.A)
                {
                    //obsługa funkcjonalności: A. obliczrenie sumy wyrazu ciągu liczbowego(in-line)
                    //ustalanie kolejnosci wczytywania danych wejściowych a1 a2 a3 ...an
                    //potwierdzenie realizacji wybranej funkcjonalności
                    Console.WriteLine("\n\t realoizacja funkcjonalności A. obliczrenie sumy wyrazu ciągu liczbowego(in-line)");
                    //deklaracje lokalne
                    int MPn;
                    float MPSuma, MPa;
                    // wczytanie n 
                    Console.WriteLine(" \tpodaj wartośc dla n");
                    while (!int.TryParse(Console.ReadLine(), out MPn))
                    {
                        //gdy był błąd 
                        Console.WriteLine("\n\t ERROR: wystąpił niedozwolony znak w zapisie wartości dla n !!! ");
                        Console.Write("\n\t Podaj wartość dla n jeszcze raz ");

                    }
                    //n zostało wczytane
                    //obliczenie sumy wyrazów ciągu liczbowego 
                    //ustalenie stanu początkowego
                    MPSuma = 0.0F;
                    for (int MPi = 1; MPi <= MPn; MPi++)  //i++ odpowiada instrukcji : i = i +1
                    {
                        //wczytanie i-tego wyrazu  ciągu liczbowego

                        Console.WriteLine("\n\t podaj wartośc {0} wyrazu cięgu liczbowego", MPi);
                        while (!float.TryParse(Console.ReadLine(), out MPa))
                        {
                            Console.WriteLine("\n\t ERROR wystąpił niedozolonyu znak w zapisie wartości {0} - tego wyrazu ciągu liczbowego");
                            Console.Write("\n\t podaj artośc dla teog wyrazu jeszcze raz");


                        }

                        //tutaj a (i) jest wczytane
                        // dodanie wczytanego wyrazu ciągu liczbowegho
                        // dodanie wczytanego wyrazu do obliczanej sumy wyrazów
                        MPSuma = MPSuma + MPa; //suma +=a
                        //wypisanie wyniku obliczeń
                        Console.WriteLine("\n\t wynik obliczeń: suma {0}  wyrazów ciągu liczbowego jest równa: {1}", MPn, MPSuma);
                    }

                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.B)
                {

                    Console.WriteLine("\n\t Realizacja funkcjonalności B obliczenie sumy metodą method call");
                    // wyswietlenie wyniku dodawania ( method call)
                    Console.WriteLine("Wynik sumowania to: " + MPobliczanieSumy());
                    


                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.C)
                {
                    //obsługa funkcjonalności C. obliczrenie iloczynu wyrazu ciągu liczbowego(in-line)
                    int MPn;
                    float MPiloczyn, MPa;
                    // wczytanie n 
                    Console.WriteLine("\n\t podaj wartośc dla n");
                    while (!int.TryParse(Console.ReadLine(), out MPn))
                    {
                        //gdy był błąd 
                        Console.WriteLine("\n\t ERROR: wystąpił niedozwolony znak w zapisie wartości dla n !!! ");
                        Console.Write("\n\t Podaj wartość dla n jeszcze raz ");

                    }
                    //n zostało wczytane
                    //obliczenie iloczynu wyrazów ciągu liczbowego 
                    //ustalenie stanu początkowego
                    MPiloczyn = 1.0F;
                    for (int MPi = 1; MPi <= MPn; MPi++)  //i++ odpowiada instrukcji : i = i +1
                    {
                        //wczytanie i-tego wyrazu  ciągu liczbowego

                        Console.WriteLine("\n\t podaj wartośc {0} wyrazu cięgu liczbowego", MPi);

                        while (!float.TryParse(Console.ReadLine(), out MPa))
                        {
                            Console.WriteLine("\n\t ERROR wystąpił niedozolonyu znak w zapisie wartości {0} - tego wyrazu ciągu liczbowego");
                            Console.Write("\n\t podaj artośc dla teog wyrazu jeszcze raz");


                        }


                        //tutaj a (i) jest wczytane

                        // wykonanie mnożenia iloczyn * a
                        MPiloczyn = MPiloczyn * MPa; //iloczyn *=a
                        //wypisanie wyniku obliczeń
                        Console.WriteLine("\n\t wynik obliczeń: ilczyn {0}  wyrazów ciągu liczbowego jest równa: {1,7:F3}", MPn, MPiloczyn);
                    }

                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.D)
                {
                    Console.WriteLine("\n\tobsługa funkcjonalnośći D. obliczrenie iloczynu wyrazu ciągu liczbowego(method-call");
                    // wyswietlenie wyniku iloczynu method call
                    Console.WriteLine("Wynik iloczynu to: " + MPobliczanieIloczynu());
                    
                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.E)
                {
                    Console.WriteLine("\n\t Realizacja opcji E : obliczenie średniej arytmetycznej ");

                    // deklaracja

                    int MPa, MPn, MPi;
                    double MPw = 0.0;

                    //Pobierz od użytkownika liczbe elementów
                    Console.WriteLine("\n\t POdaj liczbe elemntów");

                    MPn = int.Parse(Console.ReadLine());

                    for (MPi = 0; MPi < MPn; MPi++)
                    {
                        Console.WriteLine("\n\t podaj kolejna liczbę ");
                        //Pobierz od użytkownika kolejny element
                        MPa = int.Parse(Console.ReadLine());
                        MPw += MPa;
                    }
                    Console.WriteLine("\n\t średnia wynosi: ");

                    //Pokaz wynik
                    Console.WriteLine(MPw / MPn);



                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.F)
                {
                    Console.WriteLine("Średnia arytmetyczna to: " + MPSredniaArtmetyczna());
                    Console.WriteLine("");


                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.G)
                {//obliczam średnia ważoną ciągu liczbowego
                    /* kolejnośc wczytywania danych wejściowych : n , a1, a2, a3, a4, a5,...*/
                    int MPn;
                    //wupisanie metryki realizowanej funkcjonalności

                    Console.WriteLine("\n\t obliczam średnia ważoną:");
                    do
                    { // warunek wejściowy n: n>0
                        //wczytanie wartości n
                        Console.WriteLine("\n\t podaj ilośc n par (liczba waga ) ciągu liczbowego");
                        while (!int.TryParse(Console.ReadLine(), out MPn))
                        { Console.WriteLine("\n\t ERROR : w zapisie liczności ciągu liczbowego n wystąpił niedozwolony znak ");
                            Console.WriteLine("\n\t Podaj wartość n jeszcze raz ");
                        }//sprawdzenie stanu wejściowego
                        if (MPn <= 0)
                        {
                            Console.WriteLine("\n\t ERROR : licznośc ciągu liczbowego n musi być > 0");
                            Console.WriteLine("\n\t Podaj wartośc n jeszcze raz");

                        }
                    }
                    while (MPn <= 0); //gdy warunek n <=0 przyjmuje wartośc true to nastąpi  powtórzenie wczytania wartości n 
                    //deklaracje uzupełniające 
                    float MPa, MPw, MPlicznik, MPmianownik;
                    do //dla zapewnienia  że suma wag > 0.0
                    { //ustalenie początkowych wartości  dla zmiennych MPlicznik i MPmianownik
                        MPlicznik = 0.0F; MPmianownik = 0.0F;
                        //obliczenie wartości licznika i mianownika 
                        for (int MPi = 1; MPi <= MPn; MPi++)
                        {
                            Console.WriteLine("\n\t Podaj {0} -ą liczbę a: ", MPi);
                            while (!float.TryParse(Console.ReadLine(), out MPa))
                            {
                                Console.WriteLine("\n\t ERROR :  w zapisie {0} - ej danej liczby wystąpił niedozwolony znak ", MPi);
                                Console.WriteLine("\n\t Podaj tą liczbę jeszcze raz ");
                            }
                            do //dal zapewnienia że każde wi >=0
                            {
                                Console.WriteLine("\n\t Podaj {0} -a wagę w: ", MPi);
                                while (!float.TryParse(Console.ReadLine(), out MPw))
                                {
                                    Console.WriteLine("\n\t ERROR:  w zapisie {0} -ej wagi wystapił niedozwolony znak ", MPi);
                                    Console.WriteLine("\n\t Podaj tę wagę jeszcze raz");
                                }
                                //wypisanie komunikatu gdy wczytana waga wi<0.0
                                if (MPw < 0.0F)
                                {
                                    Console.WriteLine("\n\t ERROR: waga nie może być liczbą ujemną ", MPi);
                                    Console.WriteLine("\n\t podaj wartośc wagi jeszcze raz");
                                }
                            }
                            while (MPw < 0.0F);
                            //sumowanie iloczynów ai*aw
                            MPlicznik = MPmianownik + MPw;
                            //sumowanie wag: wi
                            MPmianownik = MPmianownik + MPw;
                        }
                        if (MPmianownik == 0.0F)
                        {
                            Console.WriteLine("\n\t suam wag musi być większa od zera");
                            Console.WriteLine("\n\t wprowadź dane jeszcze raz");

                        }
                    }
                    while (MPmianownik == 0.0F);
                    //deklaracja uzupełniająca 
                    float MPśredniaważona;
                    //obliczenie średniej ważonej 
                    MPśredniaważona = MPlicznik / MPmianownik;
                    //wpisanie wyniku obliczeń : średniej ważonej 
                    Console.WriteLine("\n\n\t średnia ważona {0} wczytanych liczb z wagami jest równa : {1,6:F3}", MPn, MPśredniaważona);
                    Console.WriteLine("\n\t Średnia ważona ( z zaokrągleniem do 2 miejsc po przecinku ): {0,6:F2}", Math.Round(MPśredniaważona, 2));
                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.H)
                {




                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.I)
                {


                    Console.WriteLine("");
                    Console.WriteLine("Ile kilo żyta");
                    float a;
                    while (!float.TryParse(Console.ReadLine(), out a))
                        Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
                    Console.WriteLine("Ile kilo przenicy: ");
                    float b;
                    while (!float.TryParse(Console.ReadLine(), out b))
                        Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
                    Console.WriteLine("Podaj Podaj cenę za kilo: ");
                    float kg;
                    while (!float.TryParse(Console.ReadLine(), out kg))
                        Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
                    Console.WriteLine("Podaj cenę za kilo: ");
                    float kg1;
                    while (!float.TryParse(Console.ReadLine(), out kg1))
                        Console.WriteLine("To nie jest liczba, podaj wartosc jeszcze raz.");
                    float cena = (a * kg + b * kg1) / (kg + kg1);

                    Console.WriteLine("Wynik średniej ważonej to: " + cena);
                    Console.WriteLine("");


                }

                else if (wybranafunkcjonalność.Key == ConsoleKey.J)
                {


                    Console.WriteLine("Średnia arytmetyczna to: " + MPObliczanieJednostkiPaszy());
                    Console.WriteLine("");

                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.K)
                {


                    Console.WriteLine("Program do obliczania średniej harmocznicznej n liczb\n");

                    int n;
                    bool sukces;
                    double mianownik, sr;

                    do
                    {
                        Console.WriteLine("\nPodaj ile liczb chcesz użyć do średniej harmoczninej: ");
                        sukces = int.TryParse(Console.ReadLine(), out n);
                        if (!sukces)
                            Console.WriteLine("nieprawidłowy format liczby!");
                        else if (n <= 0)
                            Console.WriteLine("Ilość liczb musi być dodatnia!");

                    } while (!sukces || n <= 0);

                    for (int i = 1; i <= n; i++)
                    {
                        Console.WriteLine("Podaj a{0}:", i);
                        int a = int.Parse(Console.ReadLine());

                        mianownik = 1 / a;

                        sr = n / mianownik;

                        Console.WriteLine("Średniaharmoniczna  wynosi {0:F3}",  sr);
                        Console.WriteLine("");
                    }

                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.L)
                {


                    Console.WriteLine("Srednia tych liczb to: " + MPSrednia_Harmoniczna());

                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.M)
                {


                    Console.WriteLine("Srednia tych liczb to: " + MPSrednia_Geometryczna());

                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.N)
                {




                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.O)
                {

                    int db_n;
                    float db_wynik;
                    float db_a, db_D, db_S = 0.0f;
                    Console.WriteLine("\n\tObliczamy średnią kwadratową wyrazów ciągu arytmetycznego");

                    do  //dla zapewnienia spełnienia warunku wejściowego dla n, n>0
                    {   //wczytanie wartości n
                        Console.Write("\n\tPodaj wartość (liczbę) n: ");
                        while (!int.TryParse(Console.ReadLine(), out db_n))
                        {
                            Console.WriteLine("\n\tERROR: w zapisie liczby n wystąpił niedozwolony znak");
                            Console.Write("\n\tPodaj wartość n jeszcze raz, ale uważaj, co piszesz.");
                        }

                        //sprawdzenie warunku wejściowego
                        if (db_n <= 0)
                        {
                            Console.WriteLine("\n\tERROR: liczba musi być > 0");
                            Console.Write("\n\tPodaj wartość n jeszcze raz, ale uważaj, co piszesz.");
                        }
                    } while (db_n <= 0); /* gdy warunek n <= 0 przyjmie wartość true, 
                                 to nastąpi powtórzenie wartości n */

                    //obliczenie sumy wyrazów ciągu liczbowego
                    for (int db_i = 1; db_i <= db_n; db_i++)
                    {
                        Console.Write("\n\tPodaj {0}-ą wartość ciągu liczbowego: ", db_i);
                        while (!float.TryParse(Console.ReadLine(), out db_a))
                        {
                            Console.WriteLine("\n\tERROR: w zapisie {0}-go wyrazu ciągu liczbowego"
                                + "wystąpił niedozwolony \n\t\t znak", db_i);
                            Console.Write("\n\tPodaj wartość wyrazu ciągu liczbowego jeszcze raz,"
                                + "ale uważaj\n\t co piszesz: ");

                        }
                        /*w tym miejscu wartość wyrazu a jest "poprawna"
                         * obliczenie wyniku ze wzoru na średnią kwadratową */
                        db_S = (float)Math.Pow(db_S, 2) + (float)Math.Pow(db_a, 2); //sumowanie licznika

                    }

                    db_D = db_S / db_n;     //podzielenie licznika przez n
                    db_wynik = (float)Math.Sqrt(db_D);  //pierwiastek kw. z otrzymanej liczby
                    Console.WriteLine("\n\tŚrednia kwadratowa podanych wyrazów jest równa {0,6:F3}", db_wynik);
                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.P)
                {




                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.Q)
                {




                }
                else if (wybranafunkcjonalność.Key == ConsoleKey.R)
                {




                }
                else if (wybranafunkcjonalność.Key != ConsoleKey.X)
                {
                    //sygnalizacja błędu
                    Console.WriteLine("ERROR  naciśnąłeś klawisz który nieodpowiada żadnej z mojich funkcjonalności");
                    Console.WriteLine("wybierz ponownie wymaganą funkcjonalność ");


                    //chwilowe zatrzymanie proghramu
                    Console.Write("\n\t dlakontynuacji programu naicśnij dowolny klawisz ...");
                    Console.ReadKey();
                }
               

            } while (wybranafunkcjonalność.Key != ConsoleKey.X);
            //nacisnął klawisz z literą E
            //wypisanie danych o autorze programu
            Console.WriteLine("\n\t autor programu Mateusz Piwowarski grupa 1 - sobota ");
            //chwilowe zatrzymanie proghramu
            Console.Write("\n\t dla zakończenia programu naicśnij dowolny klawisz ...");
            Console.ReadKey();

        }
    }
}
